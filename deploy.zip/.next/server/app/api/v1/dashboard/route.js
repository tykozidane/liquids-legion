"use strict";(()=>{var t={};t.id=222,t.ids=[222],t.modules={20399:t=>{t.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:t=>{t.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},78893:t=>{t.exports=require("buffer")},84770:t=>{t.exports=require("crypto")},76162:t=>{t.exports=require("stream")},21764:t=>{t.exports=require("util")},79604:(t,a,e)=>{e.r(a),e.d(a,{originalPathname:()=>T,patchFetch:()=>p,requestAsyncStorage:()=>u,routeModule:()=>l,serverHooks:()=>S,staticGenerationAsyncStorage:()=>d});var o={};e.r(o),e.d(o,{POST:()=>m});var n=e(49303),s=e(88716),r=e(60670),_=e(47534),E=e(88784),i=e(51744),h=e.n(i),c=e(87070);async function m(t){try{let{userId:a}=await t.json(),e=await (0,_.Rt)(t,a);if(!e.status)return c.NextResponse.json({status:"99",message:e.message,data:{}},{status:200});let o=h()().format("MMMM YYYY"),n=await (0,E.I)(`WITH totals AS (
    SELECT
        SUM(CASE
            WHEN created_at >= date_trunc('month', CURRENT_DATE)
                THEN price
            ELSE 0
        END) AS this_month_total,
        SUM(CASE
            WHEN created_at >= date_trunc('month', CURRENT_DATE) - interval '1 month'
            AND created_at < date_trunc('month', CURRENT_DATE)
                THEN price
            ELSE 0
        END) AS last_month_total
    FROM opr.transactions
)
SELECT 
    this_month_total,
    last_month_total,
    ROUND(
        CASE 
            WHEN last_month_total = 0 THEN
                CASE 
                    WHEN this_month_total = 0 THEN 0
                    ELSE this_month_total / 1000
                END
            else
            CASE
            WHEN this_month_total = 0 THEN
                (1 / last_month_total) * 100
                    ELSE (this_month_total / last_month_total) * 100
                END
        END, 2
    ) AS percentage_change
from totals;
`),s=await (0,E.I)(`WITH totals AS (
    SELECT
        COUNT(*) FILTER (
            WHERE created_at >= date_trunc('month', CURRENT_DATE)
        ) AS this_month_count,
        
        COUNT(*) FILTER (
            WHERE created_at >= date_trunc('month', CURRENT_DATE) - interval '1 month'
            AND created_at < date_trunc('month', CURRENT_DATE)
        ) AS last_month_count
    FROM opr.transactions
)
SELECT 
    this_month_count,
    last_month_count,
    ROUND(
        CASE 
            WHEN last_month_count = 0 THEN
                CASE 
                    WHEN this_month_count = 0 THEN 0
                    ELSE this_month_count * 100
                END
            else
            CASE
            WHEN this_month_count = 0 THEN
                (1 / last_month_count) * 100
                    ELSE (this_month_count / last_month_count) * 100
                END
        END, 2
    ) AS percentage_change
from totals;

`),r=await (0,E.I)(`WITH totals AS (
    SELECT
        coalesce(sum(cardinality(items)) FILTER (
            WHERE created_at >= date_trunc('month', CURRENT_DATE)
        ),0) AS this_month_total, 
        coalesce(sum(cardinality(items)) FILTER (
            WHERE created_at >= date_trunc('month', CURRENT_DATE) - interval '1 month'
                AND created_at < date_trunc('month', CURRENT_DATE)
        ), 0) AS last_month_total
    FROM opr.transactions
)
SELECT 
    this_month_total,
    last_month_total,
    ROUND(
        CASE 
            WHEN last_month_total = 0 THEN
                CASE 
                    WHEN this_month_total = 0 THEN 0
                    ELSE this_month_total * 100
                END
            else
            CASE
            WHEN this_month_total = 0 THEN
                (1 / last_month_total) * 100
                    ELSE (this_month_total / last_month_total) * 100
                END
        END, 2
    ) AS percentage_change
from totals;
`),i=await (0,E.I)(`WITH all_items AS (
    SELECT unnest(items) AS item
    FROM opr.transactions 
    WHERE created_at >= date_trunc('month', CURRENT_DATE)
),
parsed_items AS (
    SELECT 
        item->>'product' AS product,
        (item->>'peace')::int AS qty
    FROM all_items
)
SELECT 
    product,
    SUM(qty) AS total_sales
FROM parsed_items
GROUP BY product
ORDER BY total_sales DESC
LIMIT 1;
                `),m=await (0,E.I)(`
                WITH months AS (
    SELECT to_char(date_trunc('month', CURRENT_DATE) - interval '1 month' * n, 'YYYY-MM') AS month,
           date_trunc('month', CURRENT_DATE) - interval '1 month' * n AS month_start
    FROM generate_series(0, 5) AS n
),
sales_per_month AS (
    SELECT 
        to_char(date_trunc('month', created_at), 'YYYY-MM') AS month,
        SUM(COALESCE(array_length(items, 1), 0)) AS sales
    FROM opr.transactions
    WHERE created_at >= date_trunc('month', CURRENT_DATE) - interval '5 months'
    GROUP BY date_trunc('month', created_at)
)
SELECT jsonb_agg(to_jsonb(m) ORDER BY m.month) AS sales_summary
FROM (
    SELECT 
        months.month,
        COALESCE(s.sales, 0) AS sales
    FROM months
    LEFT JOIN sales_per_month s ON months.month = s.month
) AS m;
                `),l=await (0,E.I)(`
WITH monthly_data AS (
    SELECT 
    COALESCE(SUM(CASE WHEN date_trunc('month', t.created_at) = date_trunc('month', CURRENT_DATE) THEN t.total_price END), 0) AS total_this_month,
    COALESCE(SUM(CASE WHEN date_trunc('month', t.created_at) = date_trunc('month', CURRENT_DATE - interval '1 month') THEN t.total_price END), 0) AS total_last_month,
    COALESCE(COUNT(CASE WHEN date_trunc('month', t.created_at) = date_trunc('month', CURRENT_DATE) THEN t.total_price END), 0) AS transaction_this_month,
    COALESCE(COUNT(CASE WHEN date_trunc('month', t.created_at) = date_trunc('month', CURRENT_DATE - interval '1 month') THEN t.total_price END), 0) AS transaction_last_month
    FROM opr.transactions t
    WHERE t.created_at >= date_trunc('month', CURRENT_DATE - interval '1 month')
)

SELECT jsonb_build_object(
    'this_month', to_char(date_trunc('month', CURRENT_DATE), 'Month'),
    'total_this_month', total_this_month,
    'last_month', to_char(date_trunc('month', CURRENT_DATE - interval '1 month'), 'Month'),
    'total_last_month', total_last_month,
    'transaction_this_month', transaction_this_month,
    'transaction_last_month', transaction_last_month,
    'total_high_this_month', total_this_month > total_last_month,
    'percentage_total', 
    CASE 
        WHEN total_last_month = 0 or total_this_month = 0 THEN '100%' 
        ELSE 
            case 
      		when total_this_month > total_last_month then CEIL((total_last_month::decimal / total_this_month) * 100)::int || '%'
      		else CEIL((total_this_month::decimal / total_last_month) * 100)::int || '%'
            end
            
    END,
    'transaction_high_this_month', transaction_this_month > transaction_last_month,
    'percentage_transaction', 
    CASE 
        WHEN transaction_last_month = 0 or transaction_this_month = 0 THEN '100%' 
        else 
            case
      		when transaction_this_month > transaction_last_month then CEIL((transaction_last_month::decimal / transaction_this_month) * 100)::int || '%'
      		else CEIL((transaction_this_month::decimal / transaction_last_month) * 100)::int || '%'	
            end
        
    END
) AS monthly_summary
FROM monthly_data;
`),u=await (0,E.I)(`
                WITH all_items AS (
    SELECT unnest(t.items) AS item
    FROM opr.transactions t 
    WHERE t.created_at >= date_trunc('year', CURRENT_DATE)
),
parsed_items AS (
    SELECT 
        item->>'product' AS product,
        (item->>'price')::numeric AS price,
        (item->>'peace')::int AS qty
    FROM all_items
),
aggregated_items AS (
    SELECT 
        product,
        SUM(price * qty) AS total
    FROM parsed_items
    GROUP BY product
),
joined_with_products AS (
    SELECT 
        ai.product,
        ai.total,
        p.image
    FROM aggregated_items ai
    LEFT JOIN opr.products p ON p.product = ai.product
)

SELECT jsonb_agg(to_jsonb(row_data)) AS top_products
FROM (
    SELECT 
        ROW_NUMBER() OVER (ORDER BY total DESC) AS number,
        product,
        total,
        image
    FROM joined_with_products
    ORDER BY total DESC
    LIMIT 6
) AS row_data;
`),d=await (0,E.I)(`
WITH latest_transactions AS (
    SELECT id, created_at::date AS date, items, total_price , buyer_from 
    FROM opr.transactions
    ORDER BY created_at DESC
    LIMIT 6
),
flattened AS (
    SELECT 
        lt.id,
        lt.date,
        item->>'product' AS product,
        lt.total_price,
        lt.buyer_from
    FROM latest_transactions lt,
        unnest(lt.items) AS item
),
grouped AS (
    SELECT 
        id,
        date,
        array_agg(product) AS products,
        MAX(total_price) AS total,
        buyer_from
    FROM flattened
    GROUP BY id, date, buyer_from
)
SELECT jsonb_agg(to_jsonb(t2) ORDER BY t2.date DESC) AS recent_transactions
FROM grouped t2;

`),S=await (0,E.I)(`
            WITH counts AS (
    SELECT
        COUNT(*) FILTER (
            WHERE buyer_from = 'website' 
            AND created_at >= date_trunc('month', CURRENT_DATE)
        ) AS this_month_count,

        COUNT(*) FILTER (
            WHERE buyer_from = 'website'
            AND created_at >= date_trunc('month', CURRENT_DATE) - interval '1 month'
            AND created_at < date_trunc('month', CURRENT_DATE)
        ) AS last_month_count
    FROM opr.transactions
)
SELECT 
    this_month_count,
    last_month_count,
    ROUND(
        CASE 
            WHEN last_month_count = 0 THEN
                CASE 
                    WHEN this_month_count = 0 THEN 0
                    ELSE this_month_count * 100
                END
            ELSE (this_month_count::numeric / last_month_count) * 100
        END, 2
    ) AS percentage_change
FROM counts;
`),T={month:o,totalRevenue:n[0]?n[0]:{this_month_total:0,last_month_total:0,percentage_change:0},totalTransaction:s[0]?s[0]:{this_month_count:0,last_month_count:0,percentage_change:0},totalItemSold:r[0]?r[0]:{this_month_total:0,last_month_total:0,percentage_change:0},bestSellerItem:i[0]?i[0]:{product:"",total_sales:0},dataChartDashboard:m[0].sales_summary?m[0].sales_summary:{month:"",sales:0},compareTotal:l[0].monthly_summary?l[0].monthly_summary:{this_month:"",total_this_month:0,transaction_this_month:0,last_month:"",total_last_month:0,transaction_last_month:0,total_high_this_month:!0,percentage_total:"",transaction_high_this_month:!0,percentage_transaction:""},last6Transaction:d[0].recent_transactions?d[0].recent_transactions:[],bestSellerProductThisYear:u[0].top_products?u[0].top_products:[],transactionFromWebsite:S[0]?S[0]:{this_month_count:0,last_month_count:0,percentage_change:0}};return c.NextResponse.json({status:"00",message:"Get Data Succesfully",data:T},{status:200})}catch(t){return console.log(t),c.NextResponse.json({status:"1001",message:"Failed to get Data",data:{message:t.message}},{status:200})}}let l=new n.AppRouteRouteModule({definition:{kind:s.x.APP_ROUTE,page:"/api/v1/dashboard/route",pathname:"/api/v1/dashboard",filename:"route",bundlePath:"app/api/v1/dashboard/route"},resolvedPagePath:"D:\\pribadiTtyko\\github\\liquids-legion\\src\\app\\api\\v1\\dashboard\\route.ts",nextConfigOutput:"",userland:o}),{requestAsyncStorage:u,staticGenerationAsyncStorage:d,serverHooks:S}=l,T="/api/v1/dashboard/route";function p(){return(0,r.patchFetch)({serverHooks:S,staticGenerationAsyncStorage:d})}},47534:(t,a,e)=>{e.d(a,{Kz:()=>_,Rt:()=>r});var o=e(41482),n=e.n(o),s=e(17854);async function r(t,a){let e=t.headers.get("authorization");console.log("auth",e);let o=null;if(e&&e.startsWith("Bearer ")&&(o=e.split(" ")[1]),!o)return{status:!1,message:"Token undefined"};let r=process.env.NEXTAUTH_SECRET||"";try{let t=n().verify(o,r),e=await (0,s.p)(a);if(t.userId!=e)return{status:!1,message:"Its Not Your Token"};return{status:!0,message:"Success Decode",data:t}}catch(t){return console.log(t),{status:!1,message:"Authorization Failed"}}}async function _(t,a){let e=t.headers.get("authorization");console.log("auth",e);let o=null;if(e&&e.startsWith("Bearer ")&&(o=e.split(" ")[1]),!o)return{status:!1,message:"Token undefined"};let r=process.env.NEXTAUTH_SECRET||"";try{let t=n().verify(o,r),e=await (0,s.p)(a);if(t.userId!=e)return{status:!1,message:"Its Not Your Token"};if("ADMIN"!=t.role)return{status:!1,message:"You're Not Allowed"};return{status:!0,message:"Success Decode",data:t}}catch(t){return console.log(t),{status:!1,message:"Authorization Failed"}}}},88784:(t,a,e)=>{e.d(a,{I:()=>n});let o=new(require("pg")).Pool({connectionString:process.env.DATABASE_URL});async function n(t,a){let e=await o.connect();try{return(await e.query(t,a)).rows}catch(t){throw console.error("Database query error:",t),t}finally{e.release()}}},17854:(t,a,e)=>{e.d(a,{H:()=>s,p:()=>r});var o=e(84770),n=e.n(o);async function s(t){let a=n().createCipheriv("aes-256-cbc",process.env.SECRET_KEY,process.env.SECRET_VECTOR);return a.update(t,"utf8","hex")+a.final("hex")}async function r(t){let a=n().createDecipheriv("aes-256-cbc",process.env.SECRET_KEY,process.env.SECRET_VECTOR);return a.update(t,"hex","utf8")+a.final("utf8")}}};var a=require("../../../../webpack-runtime.js");a.C(t);var e=t=>a(a.s=t),o=a.X(0,[377,972,482,744],()=>e(79604));module.exports=o})();