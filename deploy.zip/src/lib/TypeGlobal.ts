export type TypeApi = {
    status: string
    message: string
    data : any
}
